DL WMS — Cédule Connectée (iPhone) — All-in-one (Offline-first)

Contenu
- index.html : page unique mobile-first (iPhone), style pro, faible charge visuelle
  - Onglets : Entrants / Prêt à livrer / Demandes
  - Rôles : Superviseur / Dispatch / Direction (Option C)
  - Offline-first : localStorage
  - “Sync” : stub simulé (prêt à brancher sur Firebase/Supabase/API)
  - Multi-site : Laval2 / Langelier (switch rapide)

Comment utiliser
1) Ouvrir index.html dans Safari iPhone (ou Chrome)
2) Tester :
   - + Conteneur
   - + Pickup
   - Demandes : Accepter / Refuser / Proposer
   - Options rapides (👤) : rôle, site, sync (stub), reset demo
3) Pour intégrer dans DL WMS :
   - Copier index.html dans ton projet DL WMS
   - Relier le bouton Retour et la bottom nav à ton routeur/navigation existante

Notes d’architecture (évolutions futures)
- Remplacer syncNow() par un vrai backend:
  - Auth (roles)
  - Realtime updates (WebSocket / Firebase)
  - Audit log server-side
  - Conflits (last-write-wins / server-authoritative)

